import { useState } from 'react';

const corrections = [
  { n: 1, cat: 'HTML', sev: 'critical', desc: 'Ajout de <head> complète avec charset, viewport, title', done: true },
  { n: 2, cat: 'SEO', sev: 'critical', desc: 'Meta description, keywords, author, robots ajoutés', done: true },
  { n: 3, cat: 'SEO', sev: 'critical', desc: 'Open Graph + Twitter Card meta tags ajoutés', done: true },
  { n: 4, cat: 'Sécurité', sev: 'critical', desc: 'Identifiants ahmed/1234 et prof/1234 retirés du HTML', done: true },
  { n: 5, cat: 'HTML', sev: 'warning', desc: 'Favicon SVG ajouté (drapeau 🇩🇿)', done: true },
  { n: 6, cat: 'Accessibilité', sev: 'warning', desc: 'role="button" + tabindex + aria-label sur toutes les cartes', done: true },
  { n: 7, cat: 'Performance', sev: 'warning', desc: 'loading="lazy" + width/height sur image professeur', done: true },
  { n: 8, cat: 'Accessibilité', sev: 'warning', desc: 'aria-live="polite" + role="log" sur le chat', done: true },
  { n: 9, cat: 'Accessibilité', sev: 'warning', desc: 'aria-label sur tous les formulaires', done: true },
  { n: 10, cat: 'Sécurité', sev: 'warning', desc: 'Numéro WhatsApp masqué (formulaire au lieu de lien direct)', done: true },
  { n: 11, cat: 'Contenu', sev: 'warning', desc: 'Markdown ** remplacé par <b> balises', done: true },
  { n: 12, cat: 'Contenu', sev: 'warning', desc: 'Texte mixte arabe/français dupliqué supprimé', done: true },
  { n: 13, cat: 'Contenu', sev: 'warning', desc: '"Frost-" corrigé en "Prüfungs-"', done: true },
  { n: 14, cat: 'Contenu', sev: 'warning', desc: 'Numérotation séances : "9/8" → "9/13" corrigé', done: true },
  { n: 15, cat: 'Performance', sev: 'warning', desc: 'Fichier CSS séparé (style.css)', done: true },
  { n: 16, cat: 'Performance', sev: 'warning', desc: 'Fichier JS séparé (script.js)', done: true },
  { n: 17, cat: 'Accessibilité', sev: 'warning', desc: 'aria-label dynamique sur boutons show/hide password', done: true },
  { n: 18, cat: 'Sécurité', sev: 'info', desc: 'rel="noopener noreferrer" complet sur liens externes', done: true },
  { n: 19, cat: 'HTML', sev: 'info', desc: '<nav> sémantique pour la navigation', done: true },
  { n: 20, cat: 'HTML', sev: 'info', desc: '<footer> sémantique pour le pied de page', done: true },
  { n: 21, cat: 'Accessibilité', sev: 'info', desc: 'Skip link "الانتقال إلى المحتوى الرئيسي" ajouté', done: true },
  { n: 22, cat: 'Accessibilité', sev: 'info', desc: 'aria-current="page" sur lien actif (via JS)', done: true },
  { n: 23, cat: 'Accessibilité', sev: 'info', desc: 'aria-label sur toutes les sections', done: true },
  { n: 24, cat: 'i18n', sev: 'info', desc: 'title="choix de la voix" → "اختيار الصوت"', done: true },
  { n: 25, cat: 'i18n', sev: 'info', desc: 'title bouton diagnostic traduit en arabe', done: true },
  { n: 26, cat: 'Performance', sev: 'info', desc: 'Styles inline déplacés vers classes CSS', done: true },
  { n: 27, cat: 'Performance', sev: 'info', desc: 'Z-index ramenés à des valeurs raisonnables (1000)', done: true },
  { n: 28, cat: 'Formulaires', sev: 'info', desc: 'Messages d\'erreur personnalisés en arabe', done: true },
  { n: 29, cat: 'Formulaires', sev: 'info', desc: 'Indicateur de force du mot de passe ajouté', done: true },
  { n: 30, cat: 'HTML', sev: 'ok', desc: 'theme-color meta tag ajouté', done: true },
];

export default function App() {
  const [copied, setCopied] = useState(false);
  const [activeFilter, setActiveFilter] = useState('all');

  const filtered = activeFilter === 'all'
    ? corrections
    : corrections.filter(c => c.sev === activeFilter);

  const handleCopy = async () => {
    try {
      const response = await fetch('/platform-corrected.html');
      const text = await response.text();
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    } catch {
      alert('Impossible de copier. Téléchargez le fichier manuellement.');
    }
  };

  const sevColors: Record<string, string> = {
    critical: '#f87171',
    warning: '#fbbf24',
    info: '#60a5fa',
    ok: '#34d399',
  };

  const sevLabels: Record<string, string> = {
    critical: 'حرج',
    warning: 'تحذير',
    info: 'معلومة',
    ok: '✓',
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: '#0b1117',
      color: '#e2e8f0',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      direction: 'rtl',
    }}>
      {/* Header */}
      <header style={{
        position: 'sticky',
        top: 0,
        zIndex: 100,
        background: 'rgba(11,17,23,0.95)',
        backdropFilter: 'blur(12px)',
        borderBottom: '1px solid #2a3a52',
        padding: '0.75rem 1.25rem',
      }}>
        <div style={{ maxWidth: 900, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
            <div style={{
              width: 36, height: 36, borderRadius: 8,
              background: 'linear-gradient(135deg, #f0b429, #34d399)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.1rem',
            }}>✅</div>
            <span style={{
              fontWeight: 800, fontSize: '1rem',
              background: 'linear-gradient(135deg, #f0b429, #34d399)',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            }}>30 Corrections Appliquées</span>
          </div>
          <div style={{
            padding: '0.4rem 1rem', borderRadius: '2rem',
            background: 'rgba(52,211,153,0.15)', color: '#34d399',
            border: '1px solid rgba(52,211,153,0.3)',
            fontWeight: 700, fontSize: '0.85rem',
          }}>
            ✅ 30/30 corrigés
          </div>
        </div>
      </header>

      <main style={{ maxWidth: 900, margin: '0 auto', padding: '2rem 1.25rem' }}>
        {/* Hero */}
        <section style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <h1 style={{
            fontSize: '1.75rem', fontWeight: 800, marginBottom: '0.5rem',
            background: 'linear-gradient(135deg, #f0b429, #34d399)',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          }}>
            Plateforme Corrigée — Prête à Déployer
          </h1>
          <p style={{ color: '#94a3b8', fontSize: '0.95rem' }}>
            الثانوية الافتراضية الجزائرية — Deutsche Sprache
          </p>
          <p style={{ color: '#64748b', fontSize: '0.8rem', marginTop: '0.5rem', direction: 'ltr' }}>
            allemand.brid-randomtv.workers.dev
          </p>
        </section>

        {/* Download Button */}
        <div style={{
          background: '#162032', border: '1px solid #2a3a52', borderRadius: 12,
          padding: '1.5rem', marginBottom: '2rem', textAlign: 'center',
        }}>
          <h3 style={{ color: '#f0b429', marginBottom: '0.75rem' }}>📥 Fichier Corrigé</h3>
          <p style={{ color: '#94a3b8', fontSize: '0.85rem', marginBottom: '1rem' }}>
            Téléchargez le fichier HTML corrigé avec les 30 corrections appliquées.
            Remplacez votre fichier actuel sur Cloudflare Workers par ce nouveau fichier.
          </p>
          <div style={{ display: 'flex', gap: '0.75rem', justifyContent: 'center', flexWrap: 'wrap' }}>
            <a
              href="/platform-corrected.html"
              download="index.html"
              style={{
                display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
                padding: '0.75rem 1.5rem', borderRadius: 8,
                background: '#f0b429', color: '#0b1117',
                fontWeight: 700, fontSize: '0.9rem',
                textDecoration: 'none',
              }}
            >
              📥 Télécharger index.html
            </a>
            <button
              onClick={handleCopy}
              style={{
                display: 'inline-flex', alignItems: 'center', gap: '0.5rem',
                padding: '0.75rem 1.5rem', borderRadius: 8,
                background: 'transparent', color: '#34d399',
                border: '1px solid rgba(52,211,153,0.3)',
                fontWeight: 700, fontSize: '0.9rem', cursor: 'pointer',
              }}
            >
              {copied ? '✅ Copié !' : '📋 Copier le code'}
            </button>
          </div>
        </div>

        {/* Stats */}
        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))',
          gap: '0.75rem', marginBottom: '2rem',
        }}>
          {[
            { n: 4, l: 'حرج', c: '#f87171' },
            { n: 11, l: 'تحذير', c: '#fbbf24' },
            { n: 12, l: 'معلومة', c: '#60a5fa' },
            { n: 3, l: 'صحيح', c: '#34d399' },
            { n: 30, l: 'مجموع', c: '#a78bfa' },
          ].map((s, i) => (
            <div key={i} style={{
              background: '#162032', border: '1px solid #2a3a52',
              borderRadius: 12, padding: '1rem', textAlign: 'center',
            }}>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: s.c }}>{s.n}</div>
              <div style={{ fontSize: '0.7rem', color: '#94a3b8', marginTop: '0.25rem' }}>{s.l}</div>
            </div>
          ))}
        </div>

        {/* Filter Tabs */}
        <div style={{
          display: 'flex', gap: '0.25rem', marginBottom: '1.5rem',
          overflowX: 'auto', paddingBottom: '0.5rem',
          borderBottom: '1px solid #2a3a52',
        }}>
          {[
            { id: 'all', label: '📁 الكل (30)' },
            { id: 'critical', label: '🔴 حرج (4)' },
            { id: 'warning', label: '🟡 تحذير (11)' },
            { id: 'info', label: '🔵 معلومة (12)' },
            { id: 'ok', label: '🟢 صحيح (3)' },
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setActiveFilter(t.id)}
              style={{
                padding: '0.5rem 1rem', borderRadius: '8px 8px 0 0',
                border: 'none', cursor: 'pointer',
                background: activeFilter === t.id ? '#162032' : 'transparent',
                color: activeFilter === t.id ? '#f0b429' : '#94a3b8',
                fontWeight: 600, fontSize: '0.8rem', whiteSpace: 'nowrap',
                borderBottom: activeFilter === t.id ? '2px solid #f0b429' : '2px solid transparent',
              }}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Corrections List */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          {filtered.map(c => (
            <div
              key={c.n}
              style={{
                display: 'flex', alignItems: 'center', gap: '0.75rem',
                padding: '0.75rem 1rem',
                background: '#162032', border: '1px solid #2a3a52',
                borderRadius: 8,
                borderRight: `4px solid ${sevColors[c.sev]}`,
              }}
            >
              <div style={{
                width: 28, height: 28, borderRadius: '50%',
                background: 'rgba(52,211,153,0.15)', color: '#34d399',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: '0.8rem', fontWeight: 700, flexShrink: 0,
              }}>✓</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
                  <span style={{
                    fontSize: '0.65rem', padding: '0.1rem 0.4rem', borderRadius: 4,
                    background: `${sevColors[c.sev]}22`, color: sevColors[c.sev],
                    fontWeight: 700,
                  }}>{sevLabels[c.sev]}</span>
                  <span style={{
                    fontSize: '0.65rem', padding: '0.1rem 0.4rem', borderRadius: 4,
                    background: 'rgba(167,139,250,0.15)', color: '#a78bfa',
                    fontWeight: 700,
                  }}>{c.cat}</span>
                  <span style={{ fontSize: '0.7rem', color: '#64748b' }}>#{c.n}</span>
                </div>
                <div style={{ fontSize: '0.85rem', color: '#e2e8f0', marginTop: '0.25rem' }}>
                  {c.desc}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Instructions */}
        <div style={{
          background: '#162032', border: '1px solid rgba(52,211,153,0.3)',
          borderRadius: 12, padding: '1.5rem', marginTop: '2rem',
        }}>
          <h3 style={{ color: '#34d399', marginBottom: '0.75rem' }}>📋 Instructions de déploiement</h3>
          <ol style={{ color: '#94a3b8', fontSize: '0.85rem', lineHeight: 2, paddingRight: '1.25rem' }}>
            <li>Téléchargez le fichier <code style={{ background: '#1a2536', padding: '0.1rem 0.4rem', borderRadius: 4, color: '#f0b429' }}>index.html</code> corrigé</li>
            <li>Connectez-vous à votre dashboard Cloudflare Workers</li>
            <li>Ouvrez votre Worker <code style={{ background: '#1a2536', padding: '0.1rem 0.4rem', borderRadius: 4, color: '#f0b429' }}>allemand.brid-randomtv.workers.dev</code></li>
            <li>Remplacez le contenu HTML par le fichier téléchargé</li>
            <li>Déployez et vérifiez que tout fonctionne</li>
          </ol>
        </div>

        {/* Footer */}
        <footer style={{
          marginTop: '3rem', paddingTop: '1.5rem',
          borderTop: '1px solid #2a3a52',
          textAlign: 'center', color: '#64748b', fontSize: '0.8rem',
        }}>
          <p>Rapport de correction — 30/30 corrections appliquées ✅</p>
          <p style={{ marginTop: '0.5rem' }}>
            الثانوية الافتراضية الجزائرية — Deutsche Sprache © 2026
          </p>
        </footer>
      </main>
    </div>
  );
}
