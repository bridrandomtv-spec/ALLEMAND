export interface Seance {
  num: number;
  title: string;
  titleDe: string;
  duration: string;
  type: string;
  locked: boolean;
  pages?: string;
}

export interface GramRule {
  id: number;
  title: string;
  titleDe: string;
  level: string;
  chapter: number;
}

export interface NavItem {
  id: string;
  icon: string;
  label: string;
}

export const navItems: NavItem[] = [
  { id: "accueil", icon: "🏠", label: "الرئيسية" },
  { id: "seances", icon: "📚", label: "الحصص" },
  { id: "biblio", icon: "🗂️", label: "المكتبة" },
  { id: "grammaire", icon: "📘", label: "القواعد" },
  { id: "devoir", icon: "📝", label: "الفرض" },
  { id: "examen", icon: "🎓", label: "البكالوريا" },
  { id: "quiz", icon: "🎯", label: "تمارين" },
  { id: "prof", icon: "🤖", label: "الأستاذ" },
  { id: "live", icon: "📹", label: "مباشر" },
  { id: "parents", icon: "👨‍👩‍👧", label: "الأولياء" },
  { id: "stats", icon: "🗺️", label: "إحصائيات" },
  { id: "compte", icon: "⚙️", label: "حسابي" },
];

export const seances: Seance[] = [
  { num: 1, title: "الحصة 1/8 — الترحيب والتعارف", titleDe: "Lektion 1 · Begrüßung", duration: "45 د", type: "📖 درس من الكتاب", locked: false, pages: "6, 7" },
  { num: 2, title: "الحصة 2/8 — المفردات الأساسية", titleDe: "Lektion 1 · Wortschatz", duration: "45 د", type: "📖 درس من الكتاب", locked: false, pages: "8, 9" },
  { num: 3, title: "الحصة 3/8 — القواعد : الفعل في الجملة", titleDe: "Lektion 1 · Grammatik I", duration: "45 د", type: "📖 درس من الكتاب", locked: false, pages: "10, 11" },
  { num: 4, title: "الحصة 4/8 — القراءة والفهم", titleDe: "Lektion 1 · Lesen", duration: "45 د", type: "📖 درس من الكتاب", locked: true, pages: "12, 13, 14" },
  { num: 5, title: "الحصة 5/8 — التطبيق الأول", titleDe: "Lektion 1 · Üben I", duration: "45 د", type: "📖 درس من الكتاب", locked: true, pages: "9, 12, 16" },
  { num: 6, title: "الحصة 6/8 — التدريب المركّب", titleDe: "Lektion 1 · Üben II", duration: "45 د", type: "📖 درس من الكتاب", locked: true, pages: "17, 18, 19, 20, 21" },
  { num: 7, title: "الحصة 7/8 — السمع والفونيتيك", titleDe: "Lektion 1 · Hören & Phonetik", duration: "45 د", type: "📖 درس من الكتاب", locked: true, pages: "22, 26" },
  { num: 8, title: "الحصة 8/8 — المحادثة والطلاقة", titleDe: "Lektion 1 · Sprechen", duration: "45 د", type: "📖 درس من الكتاب", locked: true, pages: "24" },
  { num: 9, title: "الحصة 9/8 — التحرير والكتابة", titleDe: "Lektion 1 · Schreiben", duration: "45 د", type: "📖 درس من الكتاب", locked: true, pages: "27" },
  { num: 10, title: "الحصة 10/8 — الثقافة والسياق", titleDe: "Lektion 1 · Information", duration: "45 د", type: "📖 درس من الكتاب", locked: true, pages: "28, 29" },
  { num: 11, title: "الحصة 11/8 — المراجعة الشاملة", titleDe: "Lektion 1 · Wiederholung", duration: "45 د", type: "📖 درس من الكتاب", locked: true, pages: "23" },
  { num: 12, title: "الحصة 12/8 — الجاهزية للفروض", titleDe: "Lektion 1 · Frost- & Testtraining", duration: "45 د", type: "📖 درس من الكتاب", locked: true },
  { num: 13, title: "الحصة 13/8 — مستشفى الأخطاء 🏥", titleDe: "Hôpital des erreurs", duration: "45 د", type: "📖 درس من الكتاب", locked: true },
];

export const gramRules: GramRule[] = [
  { id: 1, title: "الفعل في المرتبة الثانية", titleDe: "Das finite Verb auf Position 2", level: "A1", chapter: 1 },
  { id: 2, title: "التعريف والتنكير", titleDe: "Bestimmter & unbestimmter Artikel", level: "A1", chapter: 1 },
  { id: 3, title: "الأفعال النظامية في الحاضر", titleDe: "Regelmäßige Verben im Präsens", level: "A1", chapter: 1 },
  { id: 4, title: "الأفعال الشاذة : sein, haben, werden", titleDe: "Unregelmäßige Verben: sein, haben, werden", level: "A1", chapter: 1 },
  { id: 5, title: "الجمع : القاعدة العامة", titleDe: "Pluralbildung: Grundregeln", level: "A1", chapter: 1 },
  { id: 6, title: "حالة النصب (Akkusativ)", titleDe: "Der Akkusativ", level: "A1", chapter: 1 },
  { id: 7, title: "حالة الجر (Dativ)", titleDe: "Der Dativ", level: "A2", chapter: 1 },
  { id: 8, title: "الماضي البسيط (Präteritum)", titleDe: "Das Präteritum", level: "A2", chapter: 2 },
  { id: 9, title: "الماضي المركّب (Perfekt)", titleDe: "Das Perfekt", level: "A2", chapter: 2 },
  { id: 10, title: "الجمل الفرعية بـ weil, dass", titleDe: "Nebensätze mit weil, dass", level: "B1", chapter: 2 },
  { id: 11, title: "المبني للمجهول", titleDe: "Das Passiv", level: "B1", chapter: 3 },
  { id: 12, title: "الشرطية (Konjunktiv II)", titleDe: "Der Konjunktiv II", level: "B2", chapter: 3 },
];

export const chatSuggestions = [
  "Wie sagt man 'مرحبا' auf Deutsch?",
  "Erkläre mir den Akkusativ",
  "Was ist der Unterschied zwischen 'der', 'die', 'das'?",
  "أعطني أمثلة على الأفعال الشاذة",
  "Wie bilde ich das Perfekt?",
  "اشرح لي حالة Dativ",
];

export const chatResponses: Record<string, string> = {
  default: "مرحباً! أنا الأستاذ الافتراضي. يمكنني مساعدتك في قواعد اللغة الألمانية، المفردات، أو أي سؤال عن الوحدة 1. كيف يمكنني مساعدتك اليوم?",
  hallo: "«Hallo» تعني «مرحبا» بالعربية. 🇩🇪\n\nأمثلة :\n• Hallo, wie geht es dir? — مرحبا، كيف حالك؟\n• Hallo, ich bin Ahmed. — مرحبا، أنا أحمد.\n• Guten Morgen! — صباح الخير!\n• Guten Tag! — طاب يومك!",
  akkusativ: "📘 حالة النصب (Akkusativ)\n\nتُستعمل بعد الأفعال التي تحتاج مفعولاً به مباشراً.\n\nالأدوات :\n• der → den (m)\n• die → die (f) — لا تتغير\n• das → das (n) — لا يتغير\n• die → die (pl) — لا تتغير\n\nمثال :\n• Ich sehe den Mann. — أرى الرجل.\n• Er liest das Buch. — هو يقرأ الكتاب.",
  artikel: "📘 أدوات التعريف : der, die, das\n\n• der — للمذكر (Maskulinum)\n  → der Mann, der Tisch, der Stuhl\n• die — للمؤنث (Femininum)\n  → die Frau, die Lampe, die Tür\n• das — للمحايد (Neutrum)\n  → das Kind, das Buch, das Haus\n\n💡 نصيحة : احفظ الكلمة مع أداتها دائماً!",
  perfekt: "⏰ الماضي المركّب (Das Perfekt)\n\nالصيغة : haben/sein + Partizip II\n\nالقاعدة :\n1. معظم الأفعال تأخذ «haben»\n   → Ich habe gelernt. (تعلمت)\n2. أفعال الحركة تأخذ «sein»\n   → Ich bin gegangen. (ذهبت)\n3. Partizip II = ge + جذر + t/en\n   → lernen → gelernt\n   → gehen → gegangen",
  unregel: "📘 الأفعال الشاذة (Unregelmäßige Verben)\n\nالأهم :\n• sein (كان) → bin, bist, ist, sind, seid, sind\n• haben (عنده) → habe, hast, hat, haben, habt, haben\n• werden (يصبح) → werde, wirst, wird, werden, werdet, werden\n\n💡 هذه الأفعال يجب حفظها لأنها تستعمل في كل الجمل!",
  dativ: "📘 حالة الجر (Dativ)\n\nتُستعمل بعد حروف الجر :\nmit, bei, nach, aus, zu, von, seit\n\nالأدوات :\n• der → dem (m)\n• die → der (f)\n• das → dem (n)\n• die → den + n (pl)\n\nمثال :\n• Ich gehe mit dem Mann. — أذهب مع الرجل.\n• Sie spricht mit der Frau. — تتحدث مع المرأة.",
};

export const classes = [
  "1AS-1", "1AS-2", "2AS-1", "2AS-2", "2AS-3", "3AS-1", "3AS-2"
];

export const classLabels: Record<string, string> = {
  "1AS-1": "1AS-1 — السنة الأولى ثانوي · 30 تلميذ",
  "1AS-2": "1AS-2 — السنة الأولى ثانوي · 28 تلميذ",
  "2AS-1": "2AS-1 — السنة الثانية ثانوي · 32 تلميذ",
  "2AS-2": "2AS-2 — السنة الثانية ثانوي · 28 تلميذ",
  "2AS-3": "2AS-3 — السنة الثانية ثانوي · 32 تلميذ",
  "3AS-1": "3AS-1 — السنة الثالثة ثانوي · 26 تلميذ",
  "3AS-2": "3AS-2 — السنة الثالثة ثانوي · 24 تلميذ",
};

export const wilayas = Array.from({ length: 58 }, (_, i) => {
  const nums = ["01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","46","47","48","49","50","51","52","53","54","55","56","57","58"];
  const names = ["أدرار","الشلف","الأغواط","أم البواقي","باتنة","بجاية","بسكرة","بشار","البليدة","البويرة","تمنراست","تبسة","تلمسان","تيارت","تيزي وزو","الجزائر","الجلفة","جيجل","سطيف","سعيدة","سكيكدة","سيدي بلعباس","عنابة","قالمة","قسنطينة","المدية","مستغانم","المسيلة","معسكر","ورقلة","وهران","البيض","إليزي","برج بوعريريج","بومرداس","الطارف","تندوف","تيسمسيلت","الوادي","خنشلة","سوق أهراس","تيبازة","ميلة","عين الدفلى","النعامة","عين تموشنت","غرداية","غليزان","تيميمون","برج باجي مختار","أولاد جلال","بني عباس","عين صالح","عين قزام","تقرت","جانت","المغير","المنيعة"];
  return { value: `${nums[i]}|${names[i]}`, label: `${nums[i]} — ${names[i]}` };
});
